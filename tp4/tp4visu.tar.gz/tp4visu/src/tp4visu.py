import os

class Point: 
    def __init__(self, x, y,val):
        self.x = float(x)
        self.y = float(y)
        self.val = float(val)

    def __repr__(self):
        return "{x: " +str((self.x)) + " y:" + str((self.y)) + " v:" + str (int(self.val))+"}"

class Segment: 
    def __init__(self, x1, y1, x2, y2):
        self.x1 = float(x1)
        self.y1 = float(y1)
        self.x2 = float(x2)
        self.y2 = float(y2)
    
    def __repr__(self):
        return "{(" + str((self.x1)) + ", " + str((self.y1))+ ")(" + str((self.x2)) + ", " + str((self.y2)) + ")}"
    
def lectureData(fich):
    fichier = open(fich, 'r') 
    tabPoint = []
    nbCol = 0
    while True :
        line = fichier.readline()
        if line == '' :
          break
        (x, y, val) = line.split(" ")
        val =(val.split("\n"))[0]
        tabPoint.append( Point(x,y, val))
        if (nbCol < y):
            nbCol = int(y)
    return (tabPoint, nbCol)

def determinePlusLess(tabPoint, valToCompare):
    tabSigne = []
    for i in range(0,len(tabPoint)):
        signe = 0
        if (tabPoint[i].val < valToCompare):
            signe = -1
        else :
            signe = +1
        tabSigne.append(signe)
    return tabSigne

def marchingSquare(tabPoint, tabSigne, isoVal, nbCol):
    tabSegments = []
    for i in range(0,len(tabPoint) - (nbCol+2)):
        indexp1 = i
        indexp2 = i+1
        indexp3 = i+nbCol+1
        indexp4 = i+nbCol+2
        
        p1 = tabPoint[indexp1]          # p1---p2
        p2 = tabPoint[indexp2]          #  |   |
        p3 = tabPoint[indexp3]          # p3---p4
        p4 = tabPoint[indexp4]
            
        pointAretes = []
        if (tabSigne[indexp1] + tabSigne[indexp2] == 0):
            pointAretes.append(determinePointArete(p1,p2,isoVal))
        if (tabSigne[indexp2] + tabSigne[indexp4] == 0):
            pointAretes.append(determinePointArete(p2,p4,isoVal))
        if (tabSigne[indexp4] + tabSigne[indexp3] == 0):
            pointAretes.append(determinePointArete(p4,p3,isoVal))
        if (tabSigne[indexp3] + tabSigne[indexp1] == 0):
            pointAretes.append(determinePointArete(p3,p1,isoVal))         
            
        if (len(pointAretes) == 2):
            tabSegments.append(Segment(pointAretes[0].x, pointAretes[0].y, pointAretes[1].x, pointAretes[1].y))
        elif (len(pointAretes) == 4):
            moyenne = (p1.val + p2.val + p3.val + p4.val) / 4
            if (moyenne >= isoVal):
              tabSegments.append(Segment(pointAretes[0].x, pointAretes[0].y, pointAretes[3].x, pointAretes[3].y))
              tabSegments.append(Segment(pointAretes[1].x, pointAretes[1].y, pointAretes[2].x, pointAretes[2].y))
            else:
              tabSegments.append(Segment(pointAretes[0].x, pointAretes[0].y, pointAretes[1].x, pointAretes[1].y))
              tabSegments.append(Segment(pointAretes[2].x, pointAretes[2].y, pointAretes[3].x, pointAretes[3].y))  
            
        #TODO Si on a que deux aretes a modif c'est un cas simple, sinon c'est egale a 4 ou 0
        #pour 4 faut faire le truc de la valeur moy
        #mettre les deux points qui sont ensemble dans un ensemble de segments 
        
    return tabSegments

def determinePointArete(pt1, pt2, a):
    u = pt1.val
    v = pt2.val
    t = (a-u)/(v-u)
    Xx = ((v-a)/(v-u))*pt1.x + ((a-u)/(v-u))*pt2.x
    Xy = ((v-a)/(v-u))*pt1.y + ((a-u)/(v-u))*pt2.y
    return Point(Xx,Xy,a)

def drawPS(tabPoint, tabSegment, nbCol):
    fichier = file('resultat.ps', 'w')
    fichier.write("%!PS\n")
    coefMult = 50
    drawGrid(fichier, tabPoint, nbCol, coefMult)
#    if tableau != []:
#        premierX = tableau[0].x * coefMulti
#        premierY = tableau[0].y * coefMulti
#        fichier.write(str(premierX) + " " + str(premierY) + " moveto\n")
#    	for i in range(1, len(tableau)) :
#            fichier.write("%s %s lineto\n" % (str(tableau[i].x * coefMulti), str(tableau[i].y * coefMulti)))
#        fichier.write(str(premierX) + " " + str(premierY) + " lineto\n")
#        fichier.write("stroke\nshowpage")
#        fichier.close()
#        os.system("gs -sDEVICE=jpeg -dJPEGQ=100 -dNOPAUSE -dBATCH -dSAFER -r100x100 -sOutputFile=" +name+'.jpg '+ name +'.ps')
    return
        
def drawGrid(fichier, tabPoint, nbCol, coef):
    fichier.write("1 0 0 setrgbcolor\n")
    fichier.write("0 0 moveto\n")
#    fichier.write("(" + str(tabPoint[0].val) + ") show\n")
    for i in range(1,nbCol+1):
#        fichier.write(str(tabPoint[i].x * (coef*i)) + " " + str(tabPoint[i].y * (coef*i)) + " lineto\n")
        fichier.write(str(i*tabPoint[i].y*coef) + " 500" + " lineto\n")
#        fichier.write("(" + str(tabPoint[i].val) + ") show\n")
    fichier.write("stroke\nshowpage")
    return
    
    
if __name__ == "__main__":
    (data, nbCol) = lectureData("data.txt")
    print nbCol
    isoValue = 2
    signes = determinePlusLess(data, isoValue)
    tabSegment = marchingSquare(data, signes, isoValue, nbCol)
    drawPS(data, tabSegment, nbCol)
